

## NavBar 导航栏
> **组件名：uni-nav-bar**
> 代码块： `uNavBar`

导航栏组件，主要用于头部导航。

### [查看文档](https://uniapp.dcloud.io/component/uniui/uni-nav-bar)
#### 如使用过程中有任何问题，或者您对uni-ui有一些好的建议，欢迎加入 uni-ui 交流群：871950839 





