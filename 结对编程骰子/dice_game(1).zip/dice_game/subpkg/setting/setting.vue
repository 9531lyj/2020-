<template>
	<view class="setting">
		可以做些背景音乐大小等调节，因为uni-ui里面没有滑块组件，需导入vant，所以我就没做demo了
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style lang="scss">
.setting {
	height: 100vh;
	background: url('http://gd-hbimg.huaban.com/4e1849fe321ff056f6566d70b1c90e1892154bb511c72-ILL0hJ_fw658');
	background-repeat: no-repeat;
	background-size: cover;
	background-attachment: fixed;
	background-position: center; 
}
</style>
