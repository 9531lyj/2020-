<template>
	<view class="home">
		<!-- 标题 -->
		<view class="title">
			<image class="title-img" src="../../static/img/title.png"></image>
		</view>
		<!-- 各个游戏按钮 -->
		<view class="button">
			<!-- hover-class="none" : 清除点击高亮 -->
			<navigator hover-class="none" url="/subpkg/singlePlayer/singlePlayer">
				<button class="btn">
					<image class="btn-img" src="../../static/img/single.png"></image>	
				</button>
			</navigator>
			<navigator hover-class="none" url="/subpkg/multiPlayer/multiPlayer">
				<button class="btn">
					<image class="btn-img" src="../../static/img/multi.png"></image>
				</button>
			</navigator>
			<navigator hover-class="none" url="/subpkg/setting/setting">
				<button class="btn">
					<image class="btn-img" src="../../static/img/setting.png"></image>
				</button>
			</navigator>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		},
		
		onLoad() {
			
		},
		
		methods: {
			
		}
	}
</script>

<style lang="scss">
.home {
	height: 100vh;
	// background-image 不能加载本地资源文件
	// 解决方法:
	// 1.转为base64格式
	// 2.直接用互联网图片地址
	// 3.用image标签
	background: url('http://gd-hbimg.huaban.com/4e1849fe321ff056f6566d70b1c90e1892154bb511c72-ILL0hJ_fw658');
	background-repeat: no-repeat;
	background-size: cover;
	background-attachment: fixed;
	background-position: center; 
	.title {
		text-align: center;     
		vertical-align: middle;
		.title-img {
			width: 80%;
			margin-top: -3vh;
		}
	}
	.button {
		margin-top: -5vh;
		.btn {
			width: 80vw;
			height: 11vh;
			margin-bottom: 3vh;
			// 背景设置为透明,不能用opacoty: 0;因为该设置会让整个按钮包括内部图片文字都设为透明
			background-color: rgba(0, 0, 0, 0);
			// opacity: 0;
			border: 0px;
			.btn-img {
				margin-top: -14vh;
				width: 100%;
			}
		}
		// 去除按钮默认边框
		.btn::after {
		  border: none;
		}
	}
}
</style>
